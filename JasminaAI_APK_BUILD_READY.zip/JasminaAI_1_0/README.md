# Jasmina AI 1.0

Cross-platform Flutter + Node backend starter for a private AI companion.

Included:
- Android + iOS Flutter app
- Login/session API
- Email/phone fields stored as server-side account data placeholders
- Device biometrics (Face ID / Touch ID / Android biometrics)
- AI chat backend
- Uzbek/Russian/Turkish/English UI selector
- Voice input/output hooks
- 3D avatar screen placeholder for a VRM/GLB avatar
- Safe assistant behavior

IMPORTANT:
- Never put an API key in the mobile app.
- Never hard-code a real password in source control.
- The credentials previously shared in chat are NOT included in this project.
- Before production, replace the demo account setup with a real auth provider/database and HTTPS.
- App Store / Google Play publication requires the developer accounts and signing credentials.

## Backend
cd server
npm install
copy .env.example .env   # Windows
# or cp .env.example .env
# edit .env
npm start

## Mobile
Install Flutter, then:
cd mobile
flutter pub get
flutter run

For Android release:
flutter build apk --release

For iOS (on macOS with Xcode):
flutter build ipa --release


## Cloud APK build
This project includes `codemagic.yaml`. Codemagic generates the missing Android platform files with `flutter create`, installs packages, and builds a release APK.

Before building, set a Codemagic environment variable named `API_BASE` to the HTTPS address of your deployed Jasmina server. Do not put an OpenAI API key in the mobile app.

The generated APK is `mobile/build/app/outputs/flutter-apk/app-release.apk`.
