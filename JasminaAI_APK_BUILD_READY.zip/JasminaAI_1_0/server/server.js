import express from "express";
import session from "express-session";
import bcrypt from "bcryptjs";
import dotenv from "dotenv";
import OpenAI from "openai";

dotenv.config();
const app = express();
app.use(express.json({limit:"1mb"}));
app.use(session({
  secret: process.env.SESSION_SECRET || "change-me",
  resave:false, saveUninitialized:false,
  cookie:{httpOnly:true,sameSite:"lax",secure:false,maxAge:1000*60*60*24*7}
}));

const USER = process.env.JASMINA_USERNAME || "doston";
const PASS_HASH = bcrypt.hashSync(process.env.JASMINA_PASSWORD || "CHANGE_ME", 12);
const openai = process.env.OPENAI_API_KEY ? new OpenAI({apiKey:process.env.OPENAI_API_KEY}) : null;

function auth(req,res,next){
  if(!req.session.user) return res.status(401).json({error:"Login required"});
  next();
}

const system = `
You are Jasmina, a private AI assistant and friendly companion.
Personality: polite, cheerful, playful, caring, encouraging, age-appropriate.
Languages: Uzbek, Russian, Turkish, English. Reply in the language the user uses.
You are an AI, not a human or romantic partner. Do not pretend otherwise.
Be helpful across study, programming, writing, planning and everyday questions.
Do not provide dangerous, illegal, or age-restricted instructions, and do not help
bypass safety systems. For health issues, encourage appropriate professional care.
`;

app.post("/api/login", async (req,res)=>{
  const {username,password}=req.body||{};
  const ok = username===USER && typeof password==="string" &&
             await bcrypt.compare(password,PASS_HASH);
  if(!ok) return res.status(401).json({error:"Login yoki parol noto'g'ri"});
  req.session.user={username:USER};
  res.json({ok:true,username:USER});
});

app.get("/api/me",(req,res)=>res.json({authenticated:!!req.session.user}));
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.post("/api/chat",auth,async(req,res)=>{
  if(!openai) return res.status(503).json({error:"OPENAI_API_KEY serverda sozlanmagan"});
  const message=String(req.body?.message||"").trim();
  if(!message) return res.status(400).json({error:"Empty message"});
  try{
    const r=await openai.responses.create({
      model:process.env.AI_MODEL||"gpt-5.6-luna",
      instructions:system,
      input:message
    });
    res.json({reply:r.output_text||"Javob olinmadi"});
  }catch(e){
    console.error(e);
    res.status(500).json({error:"AI server xatosi"});
  }
});

app.listen(Number(process.env.PORT||3000),()=>console.log("Jasmina server running"));
