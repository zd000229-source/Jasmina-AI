import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:local_auth/local_auth.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';

const apiBase = String.fromEnvironment('API_BASE', defaultValue: 'http://10.0.2.2:3000');

void main()=>runApp(const JasminaApp());

class JasminaApp extends StatelessWidget {
  const JasminaApp({super.key});
  @override Widget build(BuildContext c)=>MaterialApp(
    debugShowCheckedModeBanner:false, title:'Jasmina AI',
    theme:ThemeData(brightness:Brightness.dark,useMaterial3:true,colorSchemeSeed:Colors.deepPurple),
    home:const LoginPage());
}

class Api {
  static Future<Map<String,dynamic>> login(String u,String p) async {
    final r=await http.post(Uri.parse('$apiBase/api/login'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'username':u,'password':p}));
    return jsonDecode(r.body);
  }
  static Future<Map<String,dynamic>> chat(String m) async {
    final r=await http.post(Uri.parse('$apiBase/api/chat'),
      headers:{'Content-Type':'application/json'},
      body:jsonEncode({'message':m}));
    return jsonDecode(r.body);
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState()=>_LoginPageState();
}
class _LoginPageState extends State<LoginPage>{
  final u=TextEditingController(text:'doston'), p=TextEditingController();
  final store=const FlutterSecureStorage(); final auth=LocalAuthentication();
  String err='';
  Future<void> login() async {
    final r=await Api.login(u.text,p.text);
    if(r['ok']==true){
      await store.write(key:'jasmina_user',value:u.text);
      await store.write(key:'biometric_enabled',value:'true');
      if(mounted) Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const ChatPage()));
    }else setState(()=>err=r['error']??'Kirish xatosi');
  }
  Future<void> bio() async {
    try{
      final ok=await auth.authenticate(localizedReason:'Jasmina uchun tasdiqlang',
        options:const AuthenticationOptions(biometricOnly:false,stickyAuth:true));
      if(ok && await store.read(key:'jasmina_user')!=null && mounted)
        Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const ChatPage()));
    }catch(_){}
  }
  @override Widget build(BuildContext c)=>Scaffold(body:Center(child:ConstrainedBox(
    constraints:const BoxConstraints(maxWidth:430), child:Padding(
      padding:const EdgeInsets.all(24), child:Column(mainAxisSize:MainAxisSize.min,children:[
      Text('Jasmina 🌙',style:TextStyle(fontSize:38,fontWeight:FontWeight.bold)),
      SizedBox(height:8),Text('Shaxsiy AI yordamchingiz'),
      SizedBox(height:24),
      TextField(controller:u,decoration:InputDecoration(labelText:'Login')),
      TextField(controller:p,obscureText:true,decoration:InputDecoration(labelText:'Parol')),
      SizedBox(height:12),
      FilledButton(onPressed:login,child:const Text('Kirish')),
      OutlinedButton.icon(onPressed:bio,icon:const Icon(Icons.fingerprint),label:const Text('Face ID / Touch ID / Biometrika')),
      if(err.isNotEmpty) Text(err,style:const TextStyle(color:Colors.redAccent))
    ]))));
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key});
  @override State<ChatPage> createState()=>_ChatPageState();
}
class _ChatPageState extends State<ChatPage>{
  final input=TextEditingController(); final speech=SpeechToText(); final tts=FlutterTts();
  final List<Map<String,String>> msgs=[];
  bool listening=false,busy=false;
  String lang='uz-UZ';
  Future<void> send() async {
    final m=input.text.trim(); if(m.isEmpty||busy)return;
    input.clear(); setState((){msgs.add({'who':'Doston','text':m});busy=true;});
    final r=await Api.chat(m);
    final reply=r['reply']??r['error']??'Xatolik';
    setState((){msgs.add({'who':'Jasmina','text':reply});busy=false;});
    await tts.setLanguage(lang); await tts.speak(reply);
  }
  Future<void> mic() async {
    if(!await speech.initialize())return;
    setState(()=>listening=true);
    await speech.listen(localeId:lang,onResult:(r){
      setState(()=>input.text=r.recognizedWords);
      if(r.finalResult){setState(()=>listening=false);send();}
    });
  }
  @override Widget build(BuildContext c)=>Scaffold(
    appBar:AppBar(title:const Text('Jasmina'),actions:[
      DropdownButton<String>(value:lang,items:const[
        DropdownMenuItem(value:'uz-UZ',child:Text('UZ')),DropdownMenuItem(value:'ru-RU',child:Text('RU')),
        DropdownMenuItem(value:'tr-TR',child:Text('TR')),DropdownMenuItem(value:'en-US',child:Text('EN'))],
        onChanged:(v)=>setState(()=>lang=v!))
    ]),
    body:Column(children:[
      Container(height:210,width:double.infinity,margin:const EdgeInsets.all(12),
        decoration:BoxDecoration(borderRadius:BorderRadius.circular(20),
        gradient:const RadialGradient(colors:[Color(0xff42345f),Color(0xff101018)])),
        child:const Center(child:Column(mainAxisSize:MainAxisSize.min,children:[
          Text('JASMINA',style:TextStyle(fontSize:30,fontWeight:FontWeight.w900,letterSpacing:5)),
          SizedBox(height:8),Text('3D anime avatar — VRM/GLB modulini shu yerga ulash mumkin')
        ]))),
      Expanded(child:ListView.builder(padding:const EdgeInsets.all(12),itemCount:msgs.length,
        itemBuilder:(c,i){final x=msgs[i];return Align(
          alignment:x['who']=='Doston'?Alignment.centerRight:Alignment.centerLeft,
          child:Container(margin:const EdgeInsets.all(5),padding:const EdgeInsets.all(12),
          decoration:BoxDecoration(borderRadius:BorderRadius.circular(15),
          color:x['who']=='Doston'?Colors.deepPurple.shade700:Colors.grey.shade900),
          child:Text(x['text']!)));})),
      Padding(padding:const EdgeInsets.all(10),child:Row(children:[
        IconButton(onPressed:mic,icon:Icon(listening?Icons.mic:Icons.mic_none)),
        Expanded(child:TextField(controller:input,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Jasmina bilan gaplashing...'))),
        IconButton(onPressed:send,icon:const Icon(Icons.send))
      ]))
    ]));
}
